/* 
 * File:   main.cpp
 * Author: caitlinswafford
 *
 * Created on March 9, 2015, 9:39 AM
 *      Purpose: #include <iostream>
 */

#include <iostream>
using namespace std;

//User Libraries

//Function Prototypes

//Global Constants

//Execution Begins Here!
int main(int argc, char** argv) {

    return 0;
}

