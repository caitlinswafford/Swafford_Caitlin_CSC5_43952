/* 
 * File:   main.cpp
 * Author: caitlinswafford
 *
 * Created on March 4, 2015, 9:31 AM    
 *      Purpose: To create Big C out of X's
 */

#include <iostream>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!!

int main(int argc, char** argv) {
 //Declare Variables
    char x='x';
    //Output Big C
    cout<<"    "<<x<<x<<x<<x<<endl;
    cout<<"  "<<x<<"    "<<x<<endl;
    cout<<" "<<x<<"      "<<endl;
    cout<<x<<endl;
    cout<<x<<endl;
    cout<<x<<endl;
    cout<<x<<endl;
    cout<<" "<<x<<"      "<<endl;
    cout<<"  "<<x<<"    "<<x<<endl;
    cout<<"    "<<x<<x<<x<<x<<endl;
    return 0;
}

