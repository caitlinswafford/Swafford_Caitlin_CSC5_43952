/* 
 * File:   main.cpp
 * Author: caitlinswafford
 *
 * Created on March 4, 2015, 8:37 AM
 *      Purpose: Create Computer Science Initials 
 */

#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!!

int main(int argc, char** argv) {
//Declare Variables
    char c='c';//Character displays c
    char s='s';//Character displays s
    char x='*';
    char i='!';
    char o='O';
    //Output Message
    cout<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<endl;
    cout<<"   "<<c<<c<<c<<c<<"          "<<"  "<<s<<s<<s<<s<<"  "<<"       "<<i<<i<<endl;
    cout<<"  "<<c<<"     "<<c<<"        "<<""<<s<<"      "<<s<<" "<<"      "<<i<<i<<endl;
    cout<<" "<<c<<"         " <<"     "<<s<<"               "<<i<<i<<endl;
    cout<<c<<"                "<<""<<s<<"              "<<i<<i<<endl;
    cout<<c<<"                "<<"  "<<s<<s<<s<<s<<"         "<<i<<i<<endl;
    cout<<c<<"                        "<<s<<"      "<<i<<i<<endl;
    cout<<" "<<c<<"                        "<<s<<"     "<<i<<i<<endl;
    cout<<"  "<<c<<"     "<<c<<"        "<<""<<s<<"      "<<s<<" "<<endl;
    cout<<"   "<<c<<c<<c<<c<<"          "<<"  "<<s<<s<<s<<s<<"         "<<o<<o<<endl;
    cout<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<x<<endl;
    cout<<"Computer Science is Cool Stuff!!!"<<endl;
    return 0;
}

